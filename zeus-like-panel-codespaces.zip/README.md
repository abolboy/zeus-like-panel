# Zeus-like Panel

Independent admin panel for managing users, servers, configs and dashboard statistics. This is a clean implementation and does not copy proprietary Zeus code or UI.

## Run with Docker Compose

1. Copy `.env.example` to `.env` and replace the example secrets.
2. Run `docker compose up -d --build`.
3. Open the web app on port `8080`.

The web container proxies `/api` to the backend, so the frontend works in Codespaces and on a remote VPS without hard-coded `localhost` URLs.

## GitHub Codespaces

Open the repository in a Codespace. Docker Compose is included; run:

```bash
docker compose up -d --build
```

Then open the forwarded port `8080`.

## Security notes

- Set strong, unique `POSTGRES_PASSWORD`, `JWT_SECRET`, and `ADMIN_PASSWORD` values before deployment.
- Put the panel behind HTTPS and restrict access to trusted networks where appropriate.
- Remote Xray command execution/agents are intentionally not included until authentication, authorization, validation and audit controls are designed securely.

## Current scope

- Admin login with JWT
- Dashboard
- User management
- Server management
- Config API
- PostgreSQL persistence
- Responsive frontend
- Docker Compose
- Codespaces/dev-container configuration
