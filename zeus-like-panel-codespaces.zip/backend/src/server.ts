import express,{Request,Response,NextFunction} from "express";
import cors from "cors";
import pg from "pg";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import {z} from "zod";

const {Pool}=pg, app=express();
const pool=new Pool({connectionString:process.env.DATABASE_URL});
const JWT_SECRET=process.env.JWT_SECRET!;
if(!JWT_SECRET) throw new Error("JWT_SECRET is required");
app.disable("x-powered-by");
app.use(cors({origin:true}));
app.use(express.json({limit:"100kb"}));

type AuthReq=Request & {admin?:{username:string}};
const auth=(req:AuthReq,res:Response,next:NextFunction)=>{
 const h=req.headers.authorization;
 if(!h?.startsWith("Bearer ")) return res.status(401).json({error:"unauthorized"});
 try{req.admin=jwt.verify(h.slice(7),JWT_SECRET) as {username:string};next()}
 catch{return res.status(401).json({error:"invalid token"})}
};

const userSchema=z.object({
 username:z.string().trim().min(2).max(120),
 trafficLimitBytes:z.coerce.number().int().min(0).default(0),
 expiresAt:z.string().datetime().nullable().optional()
});
const serverSchema=z.object({
 name:z.string().trim().min(1).max(120),
 address:z.string().trim().min(1).max(255),
 port:z.coerce.number().int().min(1).max(65535).default(443)
});

app.get("/api/health",async(_req,res)=>{try{await pool.query("SELECT 1");res.json({ok:true})}catch{res.status(503).json({ok:false})}});
app.post("/api/auth/login",async(req,res)=>{
 const {username,password}=req.body??{};
 if(typeof username!=="string"||typeof password!=="string") return res.status(400).json({error:"invalid credentials"});
 const configuredUser=process.env.ADMIN_USER||"admin", configuredPass=process.env.ADMIN_PASSWORD||"";
 if(username!==configuredUser||!configuredPass||password!==configuredPass) return res.status(401).json({error:"invalid credentials"});
 const token=jwt.sign({username},JWT_SECRET,{expiresIn:"12h"});
 res.json({token,username});
});

app.use("/api/users",auth);
app.use("/api/servers",auth);
app.use("/api/configs",auth);
app.use("/api/dashboard",auth);

app.get("/api/dashboard",async(_req,res)=>{
 const q=await pool.query(`SELECT
 (SELECT count(*)::int FROM users) users,
 (SELECT count(*)::int FROM users WHERE enabled) activeUsers,
 (SELECT count(*)::int FROM servers WHERE enabled) servers,
 (SELECT count(*)::int FROM configs) configs,
 COALESCE((SELECT sum(traffic_used_bytes)::bigint FROM users),0) trafficUsed`);
 res.json(q.rows[0]);
});
app.get("/api/users",async(_req,res)=>res.json((await pool.query("SELECT * FROM users ORDER BY id DESC")).rows));
app.post("/api/users",async(req,res)=>{
 const p=userSchema.safeParse(req.body); if(!p.success)return res.status(400).json({error:"invalid user data"});
 try{const r=await pool.query("INSERT INTO users(username,traffic_limit_bytes,expires_at) VALUES($1,$2,$3) RETURNING *",[p.data.username,p.data.trafficLimitBytes,p.data.expiresAt??null]);res.status(201).json(r.rows[0])}
 catch(e:any){res.status(e.code==="23505"?409:500).json({error:e.code==="23505"?"username already exists":"server error"})}
});
app.patch("/api/users/:id",async(req,res)=>{
 const id=Number(req.params.id); if(!Number.isInteger(id))return res.status(400).json({error:"invalid id"});
 const p=userSchema.partial().safeParse(req.body); if(!p.success)return res.status(400).json({error:"invalid data"});
 const r=await pool.query(`UPDATE users SET username=COALESCE($1,username),traffic_limit_bytes=COALESCE($2,traffic_limit_bytes),expires_at=COALESCE($3,expires_at),enabled=COALESCE($4,enabled) WHERE id=$5 RETURNING *`,
 [p.data.username??null,p.data.trafficLimitBytes??null,p.data.expiresAt??null,typeof req.body.enabled==="boolean"?req.body.enabled:null,id]);
 if(!r.rowCount)return res.status(404).json({error:"not found"});res.json(r.rows[0]);
});
app.delete("/api/users/:id",async(req,res)=>{await pool.query("DELETE FROM users WHERE id=$1",[req.params.id]);res.status(204).end()});

app.get("/api/servers",async(_req,res)=>res.json((await pool.query("SELECT * FROM servers ORDER BY id DESC")).rows));
app.post("/api/servers",async(req,res)=>{
 const p=serverSchema.safeParse(req.body);if(!p.success)return res.status(400).json({error:"invalid server data"});
 const r=await pool.query("INSERT INTO servers(name,address,port) VALUES($1,$2,$3) RETURNING *",[p.data.name,p.data.address,p.data.port]);res.status(201).json(r.rows[0]);
});
app.patch("/api/servers/:id",async(req,res)=>{
 const r=await pool.query("UPDATE servers SET enabled=COALESCE($1,enabled),name=COALESCE($2,name),address=COALESCE($3,address),port=COALESCE($4,port) WHERE id=$5 RETURNING *",
 [typeof req.body.enabled==="boolean"?req.body.enabled:null,req.body.name??null,req.body.address??null,req.body.port??null,req.params.id]);
 if(!r.rowCount)return res.status(404).json({error:"not found"});res.json(r.rows[0]);
});
app.delete("/api/servers/:id",async(req,res)=>{await pool.query("DELETE FROM servers WHERE id=$1",[req.params.id]);res.status(204).end()});

app.get("/api/configs",async(_req,res)=>res.json((await pool.query(`SELECT c.*,u.username,s.name server_name FROM configs c JOIN users u ON u.id=c.user_id LEFT JOIN servers s ON s.id=c.server_id ORDER BY c.id DESC`)).rows));
app.post("/api/configs",async(req,res)=>{
 const {userId,serverId,protocol,configUri}=req.body??{};
 if(!Number.isInteger(Number(userId))||typeof protocol!=="string"||typeof configUri!=="string")return res.status(400).json({error:"invalid config"});
 const r=await pool.query("INSERT INTO configs(user_id,server_id,protocol,config_uri) VALUES($1,$2,$3,$4) RETURNING *",[userId,serverId?Number(serverId):null,protocol.slice(0,30),configUri]);
 res.status(201).json(r.rows[0]);
});
app.delete("/api/configs/:id",async(req,res)=>{await pool.query("DELETE FROM configs WHERE id=$1",[req.params.id]);res.status(204).end()});

app.use((err:any,_req:Request,res:Response,_next:NextFunction)=>{console.error(err);res.status(500).json({error:"internal server error"})});
const port=Number(process.env.PORT||3001);
app.listen(port,()=>console.log(`API listening on ${port}`));
