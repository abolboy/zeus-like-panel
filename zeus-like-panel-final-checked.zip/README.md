# Zeus-like Panel

An independent, clean admin panel inspired by the feature set of VPN management dashboards. It does not copy proprietary Zeus code or UI.

## GitHub Codespaces (recommended)

```bash
docker compose up -d --build
```

Then open the forwarded **8080** port.

If you previously ran an older version and the database was created before the schema mount was added, reset the local database once:

```bash
docker compose down -v
docker compose up -d --build
```

> `down -v` deletes the local PostgreSQL data for this project. Use it only for a fresh test installation.

## Login

Create `.env` from `.env.example` and set your own values. The admin login is controlled by `ADMIN_USER` and `ADMIN_PASSWORD`. For a Codespace test, for example:

```bash
cp .env.example .env
```

Then edit `.env` and replace every placeholder secret before starting the stack.

## Local development without Docker

Backend:

```bash
cd backend
npm install
npm run dev
```

Frontend (in another terminal):

```bash
cd frontend
npm install
npm run dev
```

The local frontend expects the API to be reachable through `/api`; for the complete setup, use Docker Compose so Nginx proxies `/api` to the API container.

## Included

- JWT admin login
- Dashboard
- User CRUD basics
- Server CRUD basics
- Config API
- PostgreSQL persistence
- Responsive frontend
- Nginx API proxy
- Docker Compose
- Codespaces configuration

## Important scope note

This version does not execute arbitrary remote shell commands and does not automatically modify Xray servers. Those capabilities should only be added with a carefully designed, authenticated agent protocol, strict validation, least privilege and audit logging.
